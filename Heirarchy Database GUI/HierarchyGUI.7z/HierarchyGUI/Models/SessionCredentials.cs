﻿namespace HierarchyGUI.Models
{
    public class SessionCredentials
    {
        public static string User { get; set; }
        public static bool Status { get; set; }
        public static string ScreenName { get; set; }
    }
}
